package com.min.edu.ctrl;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.min.edu.dto.ChatRequestDto;
import com.min.edu.dto.ChatResponseDto;
import com.min.edu.service.CustomerSupportService;

@RestController
public class ChatController {

	private final CustomerSupportService service;
	
	public ChatController(CustomerSupportService service) {
		this.service = service;
	}
	
	@PostMapping("/chat")
	public ChatResponseDto chat(@RequestBody ChatRequestDto request) {
		System.out.println("요청된 request 값:" + request.getUserId());
		ChatResponseDto responseMessage = 
				service.getChatResponse(request.getUserId(), request.getMessage());
		return responseMessage;
	}
	
}








