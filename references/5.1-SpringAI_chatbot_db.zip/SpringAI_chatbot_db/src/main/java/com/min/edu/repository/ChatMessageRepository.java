package com.min.edu.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.min.edu.entity.ChatMessage;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long>{
	
	List<ChatMessage> findByUserIdOrderByCreatedAtAsc(String userId);

}
