package com.min.edu.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChatRequestDto {

	private String userId;
	private String message;
	
}
